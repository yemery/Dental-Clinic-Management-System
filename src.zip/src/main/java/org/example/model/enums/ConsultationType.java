package org.example.model.enums;

public enum ConsultationType {
    GENERAL_CONSULTATION,
    FOLLOW_UP,
    EMERGENCY
}
