package org.example.model.enums;

public enum ActCategory {
    PREVENTION,
    DENTAL_PROSTHESES,
    ORTHODONTICS,
    IMPLANTOLOGY,
    SURGERY,
    SOFT_TISSUE_CARE,
    CARE_OF_CAVITIES,
    DIAGNOSIS
}
