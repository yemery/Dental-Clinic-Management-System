package org.example.model.enums;

public enum Mutuelle {
    CNSS,CNAM,CIMR,CNOPS;
}
