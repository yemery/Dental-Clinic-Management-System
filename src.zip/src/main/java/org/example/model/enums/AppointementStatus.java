package org.example.model.enums;

public enum AppointementStatus {
    PENDING,CONFIRMED,CANCELLED;
}
