package org.example.model.enums;

public enum Gender {
    FEMALE, MALE
}
