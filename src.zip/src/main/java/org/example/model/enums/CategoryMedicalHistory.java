package org.example.model.enums;

public enum CategoryMedicalHistory {
  CONTRAINDICATION,
     Description,
   Associated_Risk,
   CHRONIC_DISEASE,
    HEREDITARY_DISEASE,
    ALLERGY,
    OTHER,
}
