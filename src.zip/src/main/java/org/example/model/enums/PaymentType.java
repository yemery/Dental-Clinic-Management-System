package org.example.model.enums;

public enum PaymentType {
    CHEQUE,
    TRANSFER,
    CREDIT_CARD,
    CASH
}
