package org.example.model.enums;

public enum Risk {
   Risk,
   MEDIUM,
    HIGH,
   UNKNOWN,
    LOW,
}
