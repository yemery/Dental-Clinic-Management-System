package org.example.model.enums;

public enum AppoitmentType {
    Priority,
    Normal,
    VIP,
    Urgent,
    Advice,
    Control,
}
