package org.example.model;

public class Assistant extends  Staff{
    private Double prime;
    @Override
    public String getType() {
        return "Assistant";
    }
}
