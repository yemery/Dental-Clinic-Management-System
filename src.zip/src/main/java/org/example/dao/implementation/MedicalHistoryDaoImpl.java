package org.example.dao.implementation;

public class MedicalHistoryDaoImpl {

}
